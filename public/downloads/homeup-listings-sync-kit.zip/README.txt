HomeUP Listings Sync Kit
========================

PropertyGuru blocks cloud servers. This kit runs on YOUR computer so listing pages
can be fetched from a normal internet connection, then synced to homeup.sg.

WHAT IS INSIDE
--------------
- SETUP.html          Step-by-step guide (open in Chrome, Edge, or Safari)
- first-time-setup    Run once after unzipping (Windows: .bat, Mac: .command)
- start-agent         Keep open while using the admin Listings Sync page
- run-full-sync       Full automated sync without using the admin UI
- .env.local.example  Template only — ask team lead for the real .env.local

ONE-TIME SETUP
--------------
1. Install Node.js 20+ from https://nodejs.org
2. Unzip this folder (e.g. Desktop/homeup-listings-sync-kit)
3. Ask your team lead for .env.local and copy it into this folder
4. Run first-time-setup (Windows: first-time-setup.bat, Mac: right-click
   first-time-setup.command → Open — see SETUP.html for Gatekeeper help)

WORKFLOW A — Admin UI (step-by-step control)
--------------------------------------------
1. Run start-agent and keep the window open
2. Open https://homeup.sg/admin and sign in
3. Go to Listings Sync (/admin/listings/pg-sources)
4. Click Refresh from Google Sheet
5. Review the preview counts
6. Click Sync to HomeUP — listings publish immediately

WORKFLOW B — Full auto sync (one click)
---------------------------------------
1. Run run-full-sync
2. Wait until the log says Done
3. Open https://homeup.sg/listings to verify

TROUBLESHOOTING
---------------
- "Missing .env.local" → ask team lead; never put keys in email or chat
- "PropertyGuru blocked" → start-agent must be running for Workflow A
- Agent offline on admin page → run start-agent before syncing
- Windows Smart App Control → only run scripts from this unzipped folder
- Mac "cannot be opened" → right-click the .command file → Open

SECURITY
--------
Do not share .env.local. It contains database and API keys.
