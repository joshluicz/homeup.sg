#!/bin/bash
set -e
cd "$(dirname "$0")"
if [ ! -f ".env.local" ]; then
  echo " ERROR: Missing .env.local — run first-time-setup.command first."
  read -r -p "Press Enter to close..."
  exit 1
fi
if [ ! -d "node_modules" ]; then
  echo " ERROR: Run first-time-setup.command before running a full sync."
  read -r -p "Press Enter to close..."
  exit 1
fi
echo ""
echo " Running full listings sync (sheet refresh, archive, import, auto-publish)..."
echo " This may take several minutes. Do not close this window."
echo ""
npm run pg:automation
echo ""
echo " Done. Check https://homeup.sg/listings to verify."
read -r -p "Press Enter to close..."
