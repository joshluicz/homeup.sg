#!/bin/bash
set -e
cd "$(dirname "$0")"

echo ""
echo " HomeUP Listings Sync Kit — first-time setup"
echo ""

if ! command -v node >/dev/null 2>&1; then
  echo " ERROR: Node.js is not installed."
  echo " Install Node 20 or newer from https://nodejs.org then run this again."
  read -r -p "Press Enter to close..."
  exit 1
fi

NODE_MAJOR=$(node -v | sed 's/^v//' | cut -d. -f1)
if [ "$NODE_MAJOR" -lt 20 ]; then
  echo " ERROR: Node 20 or newer is required. You have: $(node -v)"
  read -r -p "Press Enter to close..."
  exit 1
fi

if [ ! -f ".env.local" ]; then
  echo " ERROR: Missing .env.local"
  echo " Ask your team lead for the .env.local file and copy it into this folder."
  read -r -p "Press Enter to close..."
  exit 1
fi

echo " Installing packages..."
npm install

echo ""
echo " Installing Patchright Chrome (one-time, may take a few minutes)..."
npm run pg:install

echo ""
echo " Setup complete. Next steps:"
echo "   - Workflow A: double-click start-agent.command, then use homeup.sg/admin Listings Sync"
echo "   - Workflow B: double-click run-full-sync.command for a full automated sync"
echo ""
read -r -p "Press Enter to close..."
