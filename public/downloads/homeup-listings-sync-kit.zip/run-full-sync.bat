@echo off
cd /d "%~dp0"
if not exist ".env.local" (
  echo  ERROR: Missing .env.local — run first-time-setup.bat first.
  pause
  exit /b 1
)
if not exist "node_modules" (
  echo  ERROR: Run first-time-setup.bat before running a full sync.
  pause
  exit /b 1
)
echo.
echo  Running full listings sync (sheet refresh, archive, import, auto-publish)...
echo  This may take several minutes. Do not close this window.
echo.
call npm run pg:automation
echo.
echo  Done. Check https://homeup.sg/listings to verify.
pause
