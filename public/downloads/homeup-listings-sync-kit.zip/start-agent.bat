@echo off
cd /d "%~dp0"
if not exist ".env.local" (
  echo  ERROR: Missing .env.local — run first-time-setup.bat first.
  pause
  exit /b 1
)
if not exist "node_modules" (
  echo  ERROR: Run first-time-setup.bat before starting the agent.
  pause
  exit /b 1
)
echo.
echo  Starting HomeUP local agent...
echo  Keep this window open while syncing on https://homeup.sg/admin/listings/pg-sources
echo.
call npm run pg:agent
pause
