@echo off
cd /d "%~dp0"
echo.
echo  HomeUP Listings Sync Kit — first-time setup
echo.

where node >nul 2>nul
if errorlevel 1 (
  echo  ERROR: Node.js is not installed.
  echo  Install Node 20 or newer from https://nodejs.org then run this again.
  pause
  exit /b 1
)

for /f "tokens=1 delims=v." %%a in ('node -v') do set NODE_MAJOR=%%a
if %NODE_MAJOR% LSS 20 (
  echo  ERROR: Node 20 or newer is required. You have:
  node -v
  pause
  exit /b 1
)

if not exist ".env.local" (
  echo  ERROR: Missing .env.local
  echo  Ask your team lead for the .env.local file and copy it into this folder.
  echo  You can start from .env.local.example — do not commit real keys.
  pause
  exit /b 1
)

echo  Installing packages...
call npm install
if errorlevel 1 (
  echo  npm install failed.
  pause
  exit /b 1
)

echo.
echo  Installing Patchright Chrome (one-time, may take a few minutes)...
call npm run pg:install
if errorlevel 1 (
  echo  pg:install failed.
  pause
  exit /b 1
)

echo.
echo  Setup complete. Next steps:
echo    - Workflow A: double-click start-agent.bat, then use homeup.sg/admin Listings Sync
echo    - Workflow B: double-click run-full-sync.bat for a full automated sync
echo.
pause
