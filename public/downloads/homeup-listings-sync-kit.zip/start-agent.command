#!/bin/bash
cd "$(dirname "$0")"
if [ ! -f ".env.local" ]; then
  echo " ERROR: Missing .env.local — run first-time-setup.command first."
  read -r -p "Press Enter to close..."
  exit 1
fi
if [ ! -d "node_modules" ]; then
  echo " ERROR: Run first-time-setup.command before starting the agent."
  read -r -p "Press Enter to close..."
  exit 1
fi
echo ""
echo " Starting HomeUP local agent..."
echo " Keep this window open while syncing on https://homeup.sg/admin/listings/pg-sources"
echo ""
npm run pg:agent
